//
// CMDS.H - Various commands used in the message system (menus,
// status line, dialog boxes).
//

#if !defined( _CMDS_H )
#define _CMDS_H

const unsigned short cmAbout            = 100;
const unsigned short cmPaletteView      = 101;

#endif  // _CMDS_H
