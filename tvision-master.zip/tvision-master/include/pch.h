#define Uses_TApplication
#define Uses_TDialog
#include <tvision/tv.h>
#include <unordered_map>
#include <memory>
#include <string>
