/*------------------------------------------------------------*/
/* filename -       nmrescol.cpp                              */
/*                                                            */
/* defines the streamable name for class TResourceCollection  */
/*------------------------------------------------------------*/
/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *
 */

#define Uses_TResourceCollection
#include <tvision/tv.h>

const char * const _NEAR TResourceCollection::name = "TResourceCollection";
